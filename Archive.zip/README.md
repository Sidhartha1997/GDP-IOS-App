# GDP-IOS-App
GDP- Smart Mobility ios app

google sheet  https://docs.google.com/spreadsheets/d/1KYriASwNVqokViY7Omie2jvu_DwJIlK6aw5lTU1MtNc/edit?usp=sharing
programmatically search for map-based addresses  https://developer.apple.com/documentation/mapkit/interacting_with_nearby_points_of_interest


Reference for Saving History Data  https://www.raywenderlich.com/books/swiftui-apprentice/v1.0/chapters/9-saving-history-data

Reference for validations:  https://gist.github.com/nelglez/dd9af3e1c60b09a2d4ddb88c51c7a6a9

Reference for home screen. https://www.youtube.com/watch?v=Ck7uN5ZKzf8
