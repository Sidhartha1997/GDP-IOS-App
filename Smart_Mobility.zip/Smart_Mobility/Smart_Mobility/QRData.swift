//
//  QRData.swift
//  QRScanner
//
//  Created by KM, Abhilash a on 11/03/19.
//  Copyright © 2019 KM, Abhilash. All rights reserved.
//

import Foundation

struct QRData {
    var codeString: String?
}
