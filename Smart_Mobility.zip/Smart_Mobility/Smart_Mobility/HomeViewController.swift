//
//  ViewController.swift
//  Smart_Mobility
//
//  Created by Dodla,Narayan Reddy on 5/23/22.
//

import UIKit

class HomeViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func Login(_ sender: UIButton) {
        
    }
    
    @IBAction func ForgetPassword(_ sender: UIButton) {
        
    }
    
    @IBAction func SignUp(_ sender: UIButton) {
    
    }
    
}

